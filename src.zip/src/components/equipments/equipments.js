// GymEquipments.js

import React from 'react';
import './style.css';

const GymEquipments = () => {
  return (
    <div className="container">
      <h2>Gym Equipments</h2>
      <div className="equipments-container">
        <div className="equipment">
          <img src="./assets/treadmill.jpg" alt="Treadmill" />
          <h3>Treadmill</h3>
        </div>
        <div className="equipment">
          <img src="./assets/dumbells.jpg" alt="Dumbbells" />
          <h3>Dumbbells</h3>
        </div>
        <div className="equipment">
          <img src="./assets/bike.jpg" alt="Exercise Bike" />
          <h3>Exercise Bike</h3>
        </div>
        {/* Add more equipments as needed */}
      </div>
    </div>
  );
};

export default GymEquipments;
