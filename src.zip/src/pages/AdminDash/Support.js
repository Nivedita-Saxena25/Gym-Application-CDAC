// Filename - pages/Support.js

import React from "react";

const Support = () => {
	return (
		<div className="support">
			<h1>GeeksforGeeks Support us</h1>
		</div>
	);
};

export default Support;
