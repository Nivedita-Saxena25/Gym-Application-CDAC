// Filename - components/SidebarData.js

import React from "react";
import * as FaIcons from "react-icons/fa";
import * as AiIcons from "react-icons/ai";
import * as IoIcons from "react-icons/io";
import * as RiIcons from "react-icons/ri";

export const SidebarData = [
	{
		title: "Trainer",
		icon: <AiIcons.AiFillHome />,
		iconClosed: <RiIcons.RiArrowDownSFill />,
		iconOpened: <RiIcons.RiArrowUpSFill />,

		subNav: [
			{
				title: "Create",
				path: "/trainer/create",
				icon: <IoIcons.IoIosPaper />,
			},
			{
				title: "See",
				path: "/trainer/get",
				icon: <IoIcons.IoIosPaper />,
			},
			{
				title: "Delete",
				path: "/trainer/delete",
				icon: <IoIcons.IoIosPaper />,
			},
			{
				title: "Update",
				path: "/trainer/update",
				icon: <IoIcons.IoIosPaper />,
			},
		],
	},
	{
		title: "Membership",
		path: "/membership",
		icon: <IoIcons.IoIosPaper />,
		iconClosed: <RiIcons.RiArrowDownSFill />,
		iconOpened: <RiIcons.RiArrowUpSFill />,

		// subNav: [
		// 	{
		// 		title: "Update",
		// 		path: "/services/update",
		// 		icon: <IoIcons.IoIosPaper />,
		// 		cName: "sub-nav",
		// 	},
		// 	{
		// 		title: "Visit",
		// 		path: "/services/visit",
		// 		icon: <IoIcons.IoIosPaper />,
		// 		cName: "sub-nav",
		// 	},
		// ],
	},
	{
		title: "Schedule Class",
		path: "/scheduleclass",
		icon: <IoIcons.IoIosPaper />,
		iconClosed: <RiIcons.RiArrowDownSFill />,
		iconOpened: <RiIcons.RiArrowUpSFill />,

		subNav: [
			{
				title: "Trainer",
				path: "/trainer",
				icon: <IoIcons.IoIosPaper />,
				cName: "sub-nav",
			},
			{
				title: "Customer",
				path: "/customer",
				icon: <IoIcons.IoIosPaper />,
				cName: "sub-nav",
			},
		],
	},
	{
		title: "Payments",
		path: "/payments",
		icon: <IoIcons.IoIosPaper />,
		iconClosed: <RiIcons.RiArrowDownSFill />,
		iconOpened: <RiIcons.RiArrowUpSFill />,

		// subNav: [
		// 	{
		// 		title: "Insert",
		// 		path: "/attendance/insert",
		// 		icon: <IoIcons.IoIosPaper />,
		// 		cName: "sub-nav",
		// 	},
		// 	{
		// 		title: "See",
		// 		path: "/attendance/see",
		// 		icon: <IoIcons.IoIosPaper />,
		// 		cName: "sub-nav",
		// 	},
		// ],
	},
	{
		title: "Equipments",
		path: "/equipments",
		icon: <FaIcons.FaPhone />,
	},

	{
		title: "Feedback",
		path: "/feedback", 
		icon: <FaIcons.FaEnvelopeOpenText />,
	},

	{
		title: "ChatBot",
		path: "/chatbot",
		icon: <FaIcons.FaEnvelopeOpenText />,
	},

	{
		title: "CustomerSupport",
		path: "/custSupport",
		icon: <FaIcons.FaEnvelopeOpenText />,
	}
];