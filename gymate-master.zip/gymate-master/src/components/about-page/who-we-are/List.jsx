function List() {
  return (
    <ul className="list-disc space-y-2 px-5 font-semibold text-gray-450">
      <li>Gymat an unknown printer</li>
      <li>Scraey aretea bled makea type</li>
      <li>Bookhas survived not onlyive</li>
      <li>Centuries but also the leap electronic</li>
    </ul>
  );
}

export default List;
