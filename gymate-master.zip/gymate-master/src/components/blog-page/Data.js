import img1 from "../../images/blog-page/1.webp";
import img2 from "../../images/blog-page/2.webp";
import img3 from "../../images/blog-page/3.webp";
import img4 from "../../images/blog-page/4.webp";
import img5 from "../../images/blog-page/5.webp";
import img6 from "../../images/blog-page/6.webp";
import img7 from "../../images/blog-page/7.webp";
import img8 from "../../images/blog-page/8.webp";
import img9 from "../../images/blog-page/9.webp";
import img10 from "../../images/blog-page/10.webp";
import img11 from "../../images/blog-page/11.webp";

export const blogs = [
  {
    id: 1,
    image: img1,
    author: "Admin",
    date: "March 22, 2023",
    category: "Yoga",
    title: "Yoga For Everyone in 2023",
    desc: "Authoritatively disseminate multimedia based total linkage through market-driven methodolContinually transform integrated results vis-a-vis multidisciplinary manufacture Appropriately foster fullresearched innovation rather than backend supply. when an unknown printer took a galley.",
  },
  {
    id: 2,
    image: img2,
    author: "Admin",
    date: "March 22, 2023",
    category: "Crossfit",
    title: "Getting Back Into CrossFit After Vacation",
    desc: "Authoritatively disseminate multimedia based total linkage through market-driven methodolContinually transform integrated results vis-a-vis multidisciplinary manufacture Appropriately foster fullresearched innovation rather than backend supply. when an unknown printer took a galley.",
  },
  {
    id: 3,
    image: img3,
    author: "Admin",
    date: "March 22, 2023",
    category: "Fitness",
    title: "Meet Fitness Ambassador Grace",
    desc: "Authoritatively disseminate multimedia based total linkage through market-driven methodolContinually transform integrated results vis-a-vis multidisciplinary manufacture Appropriately foster fullresearched innovation rather than backend supply. when an unknown printer took a galley.",
  },
  {
    id: 4,
    image: img4,
    author: "Admin",
    date: "March 22, 2023",
    category: "Meditation",
    title: "The Best are European Materls Direct",
    desc: "Authoritatively disseminate multimedia based total linkage through market-driven methodolContinually transform integrated results vis-a-vis multidisciplinary manufacture Appropriately foster fullresearched innovation rather than backend supply. when an unknown printer took a galley.",
  },
  {
    id: 5,
    image: img5,
    author: "Admin",
    date: "March 22, 2023",
    category: "Boxing",
    title: "Give your Fitness a Boost with our Gym",
    desc: "Authoritatively disseminate multimedia based total linkage through market-driven methodolContinually transform integrated results vis-a-vis multidisciplinary manufacture Appropriately foster fullresearched innovation rather than backend supply. when an unknown printer took a galley.",
  },
  {
    id: 6,
    image: img6,
    author: "Admin",
    date: "March 22, 2023",
    category: "Body Building",
    title: "How to Get Fit Your Kids Moving Throughout The Summer",
    desc: "Authoritatively disseminate multimedia based total linkage through market-driven methodolContinually transform integrated results vis-a-vis multidisciplinary manufacture Appropriately foster fullresearched innovation rather than backend supply. when an unknown printer took a galley.",
  },
  {
    id: 7,
    image: img7,
    author: "Admin",
    date: "March 22, 2023",
    category: "Body Building",
    title: "Give your fitness a boost with our new gym challenge",
    desc: "Authoritatively disseminate multimedia based total linkage through market-driven methodolContinually transform integrated results vis-a-vis multidisciplinary manufacture Appropriately foster fullresearched innovation rather than backend supply. when an unknown printer took a galley.",
  },
  {
    id: 8,
    image: img8,
    author: "Admin",
    date: "March 22, 2023",
    category: "Body Building",
    title: "How to choose the right equipment for you",
    desc: "Authoritatively disseminate multimedia based total linkage through market-driven methodolContinually transform integrated results vis-a-vis multidisciplinary manufacture Appropriately foster fullresearched innovation rather than backend supply. when an unknown printer took a galley.",
  },
  {
    id: 9,
    image: img9,
    author: "Admin",
    date: "March 22, 2023",
    category: "Meditation",
    title: "Get off your butt and exercise, orders your doc",
    desc: "Authoritatively disseminate multimedia based total linkage through market-driven methodolContinually transform integrated results vis-a-vis multidisciplinary manufacture Appropriately foster fullresearched innovation rather than backend supply. when an unknown printer took a galley.",
  },
  {
    id: 10,
    image: img10,
    author: "Admin",
    date: "March 22, 2023",
    category: "Fitness",
    title: "Keep Your Body It’s Best",
    desc: "Authoritatively disseminate multimedia based total linkage through market-driven methodolContinually transform integrated results vis-a-vis multidisciplinary manufacture Appropriately foster fullresearched innovation rather than backend supply. when an unknown printer took a galley.",
  },
  {
    id: 11,
    image: img11,
    author: "Admin",
    date: "March 22, 2023",
    category: "Body Building",
    title: "Everything You Need To Know About Fitness",
    desc: "Authoritatively disseminate multimedia based total linkage through market-driven methodolContinually transform integrated results vis-a-vis multidisciplinary manufacture Appropriately foster fullresearched innovation rather than backend supply. when an unknown printer took a galley.",
  },
];
