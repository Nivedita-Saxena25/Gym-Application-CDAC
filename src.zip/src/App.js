// Merged App.js
import React from "react";
import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// Import components from the first file
import Home from "./pages/Home";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import NotFound from "./pages/Error";
import AboutUs from "./pages/aboutus";
import Facilities from "./pages/facilities";
import Plan from "./pages/plan";
import OTP from "./pages/otpform";
import BMIcalculator from "./pages/BMIcalculator";
import SideBar from "./components/Admin/SideBar";
// Import components from the second file
import Customer from "./pages/AdminDash/CreateUser";
import {
  Services,
  ServicesOne,
  ServicesTwo,
  ServicesThree,
} from "./pages/AdminDash/Services";
import { Events, EventsOne, EventsTwo } from "./pages/AdminDash/Events";
import Contact from "./pages/AdminDash/ContactUs";
import Support from "./pages/AdminDash/Support";
import Trainercr from "./pages/trainerDash/createTrainer";
import Trainerdlt from "./pages/trainerDash/deleteTrainer";
import Trainerupdt from "./pages/trainerDash/updateTrainer";
import Trainerget from "./pages/trainerDash/getTrainer";
import CustSupport from "./components/customerSupport/customerSupport";
import Equipments from "./components/equipments/equipments";
import Feedback from "./components/feedback/feedback";
import ChatBox from "./components/chatbox/chatbox";

function App() {
  return (
    <Router>
      <SideBar />
      <Routes>
        {/* Routes from the first file */}
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Home />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/aboutus" element={<AboutUs />} />
        <Route path="/facilities" element={<Facilities />} />
        <Route path="/BMIcalculator" element={<BMIcalculator />} />
        <Route path="/plans" element={<Plan />} />
        <Route path="/otpverify" element={<OTP />} />
        <Route path="*" element={<NotFound />} />

        {/* Routes from the second file */}
        <Route path="/Customer" element={<Customer />} />
        <Route path="/Customer/create" element={<createUser />} />
        <Route path="/Customer/update" element={<updateUser />} />
        <Route path="/Customer/delete" element={<deleteUser />} />
        <Route path="/Customer/get" element={<getUser />} />
        <Route path="/services" element={<Services />} />
        <Route path="/services/update" element={<ServicesOne />} />
        <Route path="/services/visit" element={<ServicesTwo />} />
        <Route path="/services/services3" element={<ServicesThree />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/events" element={<Events />} />
        <Route path="/events/events1" element={<EventsOne />} />
        <Route path="/events/events2" element={<EventsTwo />} />
        <Route path="/support" element={<Support />} />

        {/* Routes from the Admin file */}
        <Route path="/trainer" element={<trainerDash />} />
        <Route path="/trainer/create" element={<Trainercr />} />
        <Route path="/trainer/update" element={<Trainerupdt />} />
        <Route path="/trainer/delete" element={<Trainerdlt />} />
        <Route path="/trainer/get" element={<Trainerget />} />
        <Route path="/mebership" element={<mebership />} />
        <Route path="/scheduleclass/trainer" element={<scheduleclass one />} />
        <Route path="/scheduleclass/customer" element={<scheduleclass two />} />
        <Route path="/payments" element={<payments />} />
        <Route path="/equipments" element={<Equipments />} />
        <Route path="/feedback" element={<Feedback />} />
        <Route path="/chatbot" element={<ChatBox />} />
        <Route path="/custSupport" element={<CustSupport />} />
      </Routes>
    </Router>

  );
}

export default App;
