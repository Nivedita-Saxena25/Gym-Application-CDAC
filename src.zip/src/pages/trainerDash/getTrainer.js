import React, { Component } from 'react'

export default class getTrainer extends Component {
  render() {
    return (
      <div>
        <h1>Trainer</h1>
      </div>
    )
  }
}
