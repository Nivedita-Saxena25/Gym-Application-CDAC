import React, { Component } from 'react'

export default class updateTrainer extends Component {
  render() {
    return (
      <div>

        <h1>UpdateTrainer</h1>
      </div>
    )
  }
}
