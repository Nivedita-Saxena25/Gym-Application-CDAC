// eslint-disable-next-line no-undef
module.exports = {
  plugins: ["prettier-plugin-tailwindcss"],
};
