function PrimaryHeading() {
  return (
    <h1 className="text-5xl font-bold leading-normal text-white">
      MAKE YOUR BODY
      <br /> <span className="font-regular">FIT & PERFECT</span>
    </h1>
  );
}

export default PrimaryHeading;
