// //import React, { Component } from 'react'

// // export default class feedback extends Component {
// //   render() {
// //     return (
// //       <div>

// //         <h1>Feedback Form</h1>

// import React, { useState } from 'react';
// import './style.css';
// const FeedbackForm = () => {
//     // State variables to store feedback data
//     const [feedback, setFeedback] = useState('');
//     const [rating, setRating] = useState(0);

//     // Function to handle form submission
//     const handleSubmit = (e) => {
//         e.preventDefault();
//         // Send feedback data to server or perform other actions
//         console.log("Feedback submitted:", { feedback, rating });
//         // Reset form fields after submission
//         setFeedback('');
//         setRating(0);
//     };

//     return (
//         <div>
//             <h2>Feedback Form</h2>
//             <form onSubmit={handleSubmit}>
//                 <div>
//                     <label htmlFor="feedback"><h3>Feedback:</h3></label>
//                     <textarea
//                         id="feedback"
//                         value={feedback}
//                         onChange={(e) => setFeedback(e.target.value)}
//                         required
//                     />
//                 </div>
//                 <div>
//                     <label htmlFor="rating"><h3>Rating:</h3></label>
//                     <input
//                         type="number"
//                         id="rating"
//                         value={rating}
//                         onChange={(e) => setRating(parseInt(e.target.value))}
//                         min={1}
//                         max={5}
//                         required
//                     />
//                 </div>
//                 <button type="submit">Submit</button>
//             </form>
//         </div>
//     );
// };

// export default FeedbackForm;


// //       </div>
// //     )
// //   }
// // }

// FeedbackForm.js

import React, { useState } from 'react';
import './style.css'; // Import the CSS file

const FeedbackForm = () => {
  // State variables to store feedback data
  const [feedback, setFeedback] = useState('');
  const [rating, setRating] = useState(0);

  // Function to handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    // Send feedback data to server or perform other actions
    console.log("Feedback submitted:", { feedback, rating });
    // Reset form fields after submission
    setFeedback('');
    setRating(0);
  };

  return (
    <div className="container"> {/* Add a container class */}
      <div className="form-container"> {/* Add a form-container class */}
        <h2>Feedback Form</h2>
        <form onSubmit={handleSubmit}>
          <div>
            <label htmlFor="feedback">Feedback:</label>
            <textarea
              id="feedback"
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              required
            />
          </div>
          <div>
            <label htmlFor="rating">Rating:</label>
            <input
              type="number"
              id="rating"
              value={rating}
              onChange={(e) => setRating(parseInt(e.target.value))}
              min={1}
              max={5}
              required
            />
          </div>
          <button type="submit">Submit</button>
        </form>
      </div>
    </div>
  );
};

export default FeedbackForm;
