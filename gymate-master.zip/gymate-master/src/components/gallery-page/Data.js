import img1 from "../../images/gallery-page/1.webp";
import img2 from "../../images/gallery-page/2.webp";
import img3 from "../../images/gallery-page/3.webp";
import img4 from "../../images/gallery-page/4.webp";
import img5 from "../../images/gallery-page/5.webp";
import img6 from "../../images/gallery-page/6.webp";
import img7 from "../../images/gallery-page/7.webp";
import img8 from "../../images/gallery-page/8.webp";
import img9 from "../../images/gallery-page/9.webp";
import img10 from "../../images/gallery-page/10.webp";
import img11 from "../../images/gallery-page/11.webp";
import img12 from "../../images/gallery-page/12.webp";

export const gallery = [
  {
    id: 1,
    image: img1,
  },
  {
    id: 2,
    image: img2,
  },
  {
    id: 3,
    image: img3,
  },
  {
    id: 4,
    image: img4,
  },
  {
    id: 5,
    image: img5,
  },
  {
    id: 6,
    image: img6,
  },
  {
    id: 7,
    image: img7,
  },
  {
    id: 8,
    image: img8,
  },
  {
    id: 9,
    image: img9,
  },
  {
    id: 10,
    image: img10,
  },
  {
    id: 11,
    image: img11,
  },
  {
    id: 12,
    image: img12,
  },
];
